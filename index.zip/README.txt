TATC: Five Nights at the Circus
GitHub Pages build

Upload the entire folder contents, keeping the audio folder next to index.html.
Open index.html through GitHub Pages.

All included audio is original/procedural placeholder audio. Replace files in audio/
with your own recordings later if desired.

Controls:
- Left/right LIGHT and DOOR buttons
- CAMERAS opens the live camera interface
- Click a camera button to switch feeds
- Poppie appears in the camera feed as a vent encounter
- Custom Night supports AI 0-20 for all characters

This is the playable framework build. Character art is represented by labeled 3D-style
placeholders so the gameplay systems can be tested before importing final 3D models.
