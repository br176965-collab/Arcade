# Five Nights At TATC

Playable single-file HTML prototype for the TATC FNAF-style game.

## Included
- Main menu: New Game, Continue, Custom Night, Settings
- Five-night progression with localStorage Continue support
- 11 characters with randomized AI movement
- Connected camera network and live room feeds
- Office doors/lights and limited power
- Office encounters with side-specific doors
- Poppie vent mechanic
- Chatter Telephone tutorial popup
- 6 AM win state and game-over state
- Custom Night with every character independently set from AI 0-20
- Original WAV cues preserved in `audio/`

Keep the `audio/` folder beside `index.html` when uploading to GitHub Pages.
